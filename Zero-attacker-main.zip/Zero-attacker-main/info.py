import sys,os
from colorama import Fore
print(Fore.MAGENTA+"""

Zero Attacker is bunch of tools which we made for people.These all tools are for purpose of ethical hacking and discord tools.

Who is the Developer, Zero Attack is made by Asjad and Knight. This tool Rights only they have if anyone would try to copy it use under there name would be affected by the MIT Licence

Where is code? For now we Are not providing the source Code

Remember to use this tool on your own purpose no wrong use of it

This is still a beta version is over now and that's the Version 0.1


More Stars?

As we will reach 25 stars, we will add (we promised and we added the token gen for you)[COMPLETED]
As we will reach 50 stars, We will add (Facebook spammer, number spammer, reverse shell and many more ) [BETA IN PROGRESS]
As we reach 100 stars the code will be public

""")
print(Fore.RED+"""Getting Started

git clone https://github.com/AsjadOwO/Zero-attacker.git
cd Zero-Attacker
python -m pip install -r requirements.txt
for(Windows user just run the bat file (start.bat) )
Run Python zero-tool.py


License
Zero-Tool is under the MIT License
Using it without giving us credit would lead to Breaking the License law


""")