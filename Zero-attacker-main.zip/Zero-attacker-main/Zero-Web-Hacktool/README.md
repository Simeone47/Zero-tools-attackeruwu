### Preview
![image](https://github.com/AsjadOooO/Zero-attacker/blob/main/Zero-Web-Hacktool/web-buggerpng.png)

This is an part of zero-attacker one of the amazing web hacking tool 
